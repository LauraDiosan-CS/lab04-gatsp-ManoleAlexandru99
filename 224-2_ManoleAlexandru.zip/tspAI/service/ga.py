from random import uniform, randint
#from repo.getData import problParam
from repo.coordinatesToGraph import problParam
from entity.Cromozom import Chromosome

'''Functia selecteaza 2 parinti oferindu-le cromozomilor sanse direct proportionale
cu cat de bun au fitnessul'''
def selectParents(generation):
    total = 0
    sumPartiala = [0]
    
    pozMama = -1
    pozTata = -1
    
    for i in generation:
        total += i.fitness
        sumPartiala.append(total)
    
    r1 = uniform(0,total-0.01)
    r2 = uniform(0,total-0.01)
    
    i = 0
    while i < len(sumPartiala):
        if r1 >= sumPartiala[i] and r1 < sumPartiala[i+1]:
            pozMama = i
        if r2 >= sumPartiala[i] and r2 < sumPartiala[i+1]:
            pozTata = i
        if not(pozTata == -1) and not(pozMama == -1):
            i = len(sumPartiala)
        i += 1
    
    pozMama = len(generation)-1 - pozMama
    
    pozTata = len(generation)-1 - pozTata
    
    
    if pozMama == pozTata:
        if pozTata != 0:
            pozTata -= 1
        else:
            pozTata += 1
           
    parinti = [pozMama, pozTata]
    return parinti
'''
Algorimul care construieste o populatie, si timp de un nr de genereatii combina indivizii
din populatie pt a forma solutii noi
'''
def ga(generationNumber,populationSize):
    g = 0
    population = []
    #print(problParam['noNodes'])
    #print(problParam['mat'])
    bestFind = Chromosome(problParam)
    
    print("Initializam populatie")
    
    #Initializam populatie
    for i in range(populationSize):
        c = Chromosome(problParam)
        if c.fitness < bestFind.fitness:
            bestFind = c
        population.append(c)
    

    #Incepand de la populatie actuala generam una noua   
    while g < generationNumber:
        
        #print(bestFind)
        nextGen = [bestFind]
        for i in range(populationSize-1):
            
            parinti = selectParents(population)
            p1 = parinti[0]
            p2 = parinti[1]
            
            c1 = population[p1].crossover(population[p2])
            c2 = population[p2].crossover(population[p1])
            
            c1.mutation()
            c2.mutation()
            
            if c1.fitness < c2.fitness:
                betterC = c1
            else:
                betterC = c2
                
            nextGen.append(betterC)
                
            if betterC.fitness < bestFind.fitness:
                bestFind = betterC
                
        population = nextGen
        g = g + 1

        print(bestFind)
    return bestFind.repres

        
    
from random import randint, seed
import numpy as np
from logicUtils.Fitness import calcFitness
from numpy.f2py.rules import aux_rules

def generateARandomPermutation(n):
    perm = [i for i in range(n)]
    pos1 = randint(0, n - 1)
    pos2 = randint(0, n - 1)
    perm[pos1], perm[pos2] = perm[pos2], perm[pos1]
    
    return perm

def generatePermutare(n):
    perm = []
    i = 0
    for j in range(n):
        perm.append(i)
        i += 1
        
    for i in range(int(n/10)):
        r1 = randint(0,n-1)
        r2 = randint(0,n-1)
        aux = perm[r1]
        perm[r1] = perm[r2]
        perm[r2] = aux
        
    return perm

# permutation-based representation
class Chromosome:
    def __init__(self, problParam = None):
        self.__problParam = problParam  #problParam has to store the number of nodes/cities
        #self.__repres = generateARandomPermutation(self.__problParam['noNodes'])
        self.__repres = generatePermutare(self.__problParam['noNodes'])
        self.__fitness = calcFitness(problParam, self.__repres)
    
    @property
    def repres(self):
        return self.__repres 
    
    @property
    def fitness(self):
        return self.__fitness 
    
    @repres.setter
    def repres(self, l = []):
        self.__repres = l 
    
    @fitness.setter 
    def fitness(self, fit = 0.0):
        self.__fitness = fit 
    
    def crossover2(self, c):
        
        test1 = c.__repres
        test2 = self.__repres
        
        p1 = np.array(self.__repres)
        p2 = np.array(c.__repres)
        
        offspringRepres = list(p2[p1])
        
        offspring = Chromosome(self.__problParam)
        offspring.repres = offspringRepres
        offspring.fitness = calcFitness(self.__problParam, offspringRepres)
        
        if(test1 != c.repres or test2 != self.__repres):
            assert(False)
        
        return offspring
    
    def crossover(self, c):
        # order XO
        pos1 = randint(-1, self.__problParam['noNodes'] - 1)
        pos2 = randint(-1, self.__problParam['noNodes'] - 1)
        if (pos2 < pos1):
            pos1, pos2 = pos2, pos1 
        k = 0
        newrepres = self.__repres[pos1 : pos2]
        for el in c.repres[pos2:] +c.repres[:pos2]:
            if (el not in newrepres):
                if (len(newrepres) < self.__problParam['noNodes'] - pos1):
                    newrepres.append(el)
                else:
                    newrepres.insert(k, el)
                    k += 1

        offspring = Chromosome(self.__problParam)
        offspring.repres = newrepres
        offspring.fitness = calcFitness(self.__problParam, offspring.repres)
        return offspring
    
    def mutation(self):
        # insert mutation
        pos1 = randint(0, self.__problParam['noNodes'] - 1)
        pos2 = randint(0, self.__problParam['noNodes'] - 1)
        if (pos2 < pos1):
            pos1, pos2 = pos2, pos1
        el = self.repres[pos2]
        del self.repres[pos2]
        self.__repres.insert(pos1 + 1, el)
        self.__fitness = calcFitness(self.__problParam, self.__repres)
        
    def __str__(self):
        return "\nChromo: " + str(self.repres) + " has fit: " + str(self.fitness)
    
    def __repr__(self):
        return self.__str__()
    
    def __eq__(self, c):
        return self.repres == c.repres and self.fitness == c.fitness
    
def testXO():
    # seed(5)
    problParam = {'noNodes' : 10}
    c1 = Chromosome(problParam)
    c2 = Chromosome(problParam)
    print('parent1: ', c1)
    print('parent2: ', c2)
    off = c1.crossover(c2)
    print('offspring: ', off)
    
def testMutation():
    problParam = {'noNodes' : 10}
    c1 = Chromosome(problParam)
    print('before mutation: ', c1)
    c1.mutation()
    print('after mutation: ', c1)


from service.ga import ga
from repo.coordinatesToGraph import transform
generationNumber = 1000
populationSize = 100

transform("hard.txt");

print(ga(generationNumber,populationSize))
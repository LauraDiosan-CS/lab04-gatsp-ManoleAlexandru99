#filePath = "graf.txt"
#filePath= "tspTest.txt"
filePath = "medium.txt"

def getGraf(filePath):
    f = open(filePath,"r")
    nrCities = int(f.readline())
    problParam = {}
    matrice = []
    for i in range(nrCities):
        valori = f.readline()
        valori = valori.split(",")
        costLinie = []
        for j in range(len(valori)):
                costLinie.append(int(valori[j]))
        matrice.append(costLinie)
    problParam['noNodes'] = nrCities
    problParam['mat'] = matrice
    f.close()
    return problParam
    
    
problParam = getGraf(filePath)
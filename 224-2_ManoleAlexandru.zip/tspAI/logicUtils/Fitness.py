def calcFitness(problmParam,repres):
    d = 0
    mat = problmParam['mat']
    for i in range(len(repres)-1):
        d += mat[repres[i]][repres[i+1]]
    
    d += mat[repres[len(repres)-1]][repres[0]]
    
    return d

def testCalcFitness():
    problParam = { 'noNodes': 4,
                  'mat':[[0,1,2,4],[1,0,3,15],[2,3,0,6],[4,15,6,0]]
                }
    repres = [1,0,3,2]
    print(calcFitness(problParam,repres))
    
#testCalcFitness()